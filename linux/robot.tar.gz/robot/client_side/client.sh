#!/bin/bash

#defines
client=./client_side
#device
dev=/dev/ttyS0
#main cmds
COMMAND="c"
STOP_CMDS="."
#motoro cmds
MOTOR="m"
ACCEL="cma"
BRAKE="cmb"
REVERSE="cmr"
POWER="cmp"
#servo cmds
SERVO="s"
ANGLE="csa"
TEST="cst"

echo "start"
#test motion
echo "sending $ACCEL"
$client $ACCEL
sleep 1
echo "sending $BRAKE"
$client $BRAKE
sleep 1
echo "sending $REVERSE"
$client $REVERSE
sleep 1
echo "sending $ACCEL"
$client $ACCEL
sleep 1
echo "sending $BRAKE"
$client $BRAKE
sleep 1
$client $STOP_CMDS

echo "stop"
